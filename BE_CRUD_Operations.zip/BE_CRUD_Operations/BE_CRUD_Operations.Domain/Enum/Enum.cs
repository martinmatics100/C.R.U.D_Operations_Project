﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE_CRUD_Operations.Data.Enum
{
    public enum Gender
    {
        male,
        female,
        NonBinary,
        Other
    }
}
